<?php
/**
 * The View - 1-Click Fast Unpacker for cPanel / Web Hosting
 * Usage: Place this file and theview-deploy.zip in your web root, then visit:
 * https://theview.tgifgroupvn.com/unzip.php
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$zipFile = __DIR__ . '/theview-deploy.zip';

if (!file_exists($zipFile)) {
    die('<div style="font-family:sans-serif;padding:40px;text-align:center;color:#e11d48"><h2>❌ Không tìm thấy file theview-deploy.zip trong thư mục này!</h2><p>Vui lòng upload theview-deploy.zip lên cùng thư mục với unzip.php.</p></div>');
}

$zip = new ZipArchive;
$res = $zip->open($zipFile);
if ($res === TRUE) {
    $zip->extractTo(__DIR__);
    $zip->close();
    echo '<div style="font-family:sans-serif;padding:50px;text-align:center;background:#060e18;color:#cba864;min-height:100vh;">';
    echo '<h1 style="color:#ffffff;">🎉 GIẢI NÉN THÀNH CÔNG 100%!</h1>';
    echo '<p style="color:#cbd5e1;font-size:18px;">Toàn bộ website THE VIEW đã được giải nén hoàn chỉnh vào hosting.</p>';
    echo '<p><a href="/" style="display:inline-block;padding:14px 28px;background:#cba864;color:#060e18;text-decoration:none;font-weight:bold;border-radius:4px;margin-top:20px;">XEM TRANG CHỦ THE VIEW NGAY ➔</a></p>';
    echo '<p style="color:#64748b;font-size:12px;margin-top:30px;">(Bạn có thể xóa file unzip.php này sau khi giải nén xong)</p>';
    echo '</div>';
} else {
    echo '<div style="font-family:sans-serif;padding:40px;text-align:center;color:#e11d48"><h2>❌ Lỗi giải nén: Mã lỗi ' . $res . '</h2></div>';
}
?>